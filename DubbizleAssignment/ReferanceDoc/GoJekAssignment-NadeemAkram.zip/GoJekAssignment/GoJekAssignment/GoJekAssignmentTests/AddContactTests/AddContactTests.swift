//
//  AddContactTests.swift
//  GoJekAssignmentTests
//
//  Created by Nadeem Akram on 24/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import XCTest

@testable import GoJekAssignment

class AddContactTests: XCTestCase {

    var addContactViewModel: AddContactViewModel!

    override func setUp() {
        //let session = MockNetworkSession()
        addContactViewModel = AddContactViewModel(contact: nil)
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testCancelBarButtonTitle() {
        XCTAssert(addContactViewModel.cancelBarButtonTitle == AppText.Cancel.localized, "Cancel button title mismatch.")
    }
    
    func testDoneBarButtonTitle() {
        XCTAssert(addContactViewModel.doneBarButtonTitle == AppText.Done.localized, "Done button title mismatch.")
    }
    
    func testAddContact() {
        addContactViewModel.contact.value = MockContact.getComplete()
        
        let expectation = self.expectation(description: "No response recevice from contact list API.")
        
        addContactViewModel.error.bind { (error) in
            XCTAssert(error == nil, error!.localizedDescription)
        }
        addContactViewModel.isContactSync.bind { (isSync) in
            if isSync {
                expectation.fulfill()
            }
        }
        
        addContactViewModel.syncContact()
        self.waitForExpectations(timeout: 10.0, handler: nil)
    }
    
    func testAddContactResponse() {
        addContactViewModel.contact.value = MockContact.getComplete()
        
        var isContactSync = false
        let expectation = self.expectation(description: "No response recevice from contact list API.")
        
        addContactViewModel.error.bind { (error) in
            XCTAssert(error == nil, error!.localizedDescription)
        }
        addContactViewModel.isContactSync.bind { (isSync) in
            isContactSync = isSync
        }
        addContactViewModel.contact.bind { (contact) in
            if isContactSync {
                XCTAssert(contact.firstName == "Nadeem", "Contact fist name mismatch.")
                XCTAssert(contact.lastName == "Akram", "Contact last name mismatch.")
                XCTAssert(contact.phoneNumber == "+910987654321", "Contact phone number mismatch.")
                XCTAssert(contact.email == "nadeemakram2388@gmail.com", "Contact email mismatch.")
                XCTAssert(contact.favorite == false, "Contact favorite status mismatch.")
                expectation.fulfill()
            }
        }
        
        addContactViewModel.syncContact()
        self.waitForExpectations(timeout: 10.0, handler: nil)
    }

}
