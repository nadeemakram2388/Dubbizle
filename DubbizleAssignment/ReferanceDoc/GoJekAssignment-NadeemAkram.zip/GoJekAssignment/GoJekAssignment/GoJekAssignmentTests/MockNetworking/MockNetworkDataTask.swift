//
//  MockNetworkDataTask.swift
//  GoJekAssignmentTests
//
//  Created by Nadeem Akram on 24/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import Foundation

@testable import GoJekAssignment

class MockNetworkDataTask: NetworkDataTaskProtocol {
    func resume() {
    }
    
    func cancel() {
    }
}
