//
//  BadMockNetworkSession.swift
//  GoJekAssignmentTests
//
//  Created by Nadeem Akram on 24/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import Foundation

@testable import GoJekAssignment

//BadMockSession will always return error or nil response
class BadMockNetworkSession: NetworkSessionProtocol {
    func dataTask(with request: URLRequest, completionHandler: @escaping (Data?, URLResponse?, Error?) -> Void) -> NetworkDataTaskProtocol {
        
        if let mockRequest =  MockRequest.identifyRequest(request: request) {
            mockRequest.badCompletionHandler(request: request, completion: completionHandler)
        }
        
        return MockNetworkDataTask()
    }
}
