//
//  ContactDetailTests.swift
//  GoJekAssignmentTests
//
//  Created by Nadeem Akram on 24/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import XCTest

@testable import GoJekAssignment

class ContactDetailTests: XCTestCase {

    var contact: Contact!
    var contactDetailViewModel: ContactDetailViewModel!

    override func setUp() {
        contact = MockContact.getPartial()
        
        let session = MockNetworkSession()
        let client = NetworkClient(session: session)
        contactDetailViewModel = ContactDetailViewModel(contact: contact, client: client)
    }

    override func tearDown() {
    }

    func testEditBarButtonTitle() {
        XCTAssert(contactDetailViewModel.editBarButtonTitle == AppText.Edit.localized, "Contact edit button title mismatch.")
    }
    
    func testContactAPIResponse() {
        let expectation = self.expectation(description: "No response recevice from contact list API.")
        
        contactDetailViewModel.error.bind { (error) in
            XCTAssert(error == nil, error!.localizedDescription)
        }
        
        contactDetailViewModel.contact.bind { (contact) in
            if contact.phoneNumber != nil {
                expectation.fulfill()
            }
        }
        
        contactDetailViewModel.getContactDetails()
        self.waitForExpectations(timeout: 10.0, handler: nil)
    }
    
    func testUpdateContactFavoriteStatus() {
        let expectation = self.expectation(description: "No response recevice from contact list API.")
        let oldStatus = contact.favorite
        
        contactDetailViewModel.error.bind { (error) in
            XCTAssert(error == nil, error!.localizedDescription)
        }
        
        contactDetailViewModel.contact.bind { (contact) in
            if contact.favorite != oldStatus {
                expectation.fulfill()
            }
        }
        
        contactDetailViewModel.updateFavourite()
        self.waitForExpectations(timeout: 100.0, handler: nil)
    }

}
