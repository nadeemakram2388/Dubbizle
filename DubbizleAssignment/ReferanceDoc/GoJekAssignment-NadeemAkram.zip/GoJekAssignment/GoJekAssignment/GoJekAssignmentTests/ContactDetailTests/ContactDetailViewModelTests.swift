//
//  ContactDetailViewModelTests.swift
//  GoJekAssignmentTests
//
//  Created by Nadeem Akram on 24/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import XCTest

@testable import GoJekAssignment

class ContactDetailViewModelTests: XCTestCase {

    var contact: Contact!
    var contactDetailViewModel: ContactDetailViewModel!

    override func setUp() {
        contact = MockContact.getComplete()
        
        let session = MockNetworkSession()
        let client = NetworkClient(session: session)
        contactDetailViewModel = ContactDetailViewModel(contact: contact, client: client)
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testCheckContactViewModel() {
        XCTAssert(contactDetailViewModel.name == "Nadeem Akram", "Contact full name mismatch.")
        XCTAssert(contactDetailViewModel.imageURL == URL(string: "image.png"), "Contact image url mismatch.")
        XCTAssert(contactDetailViewModel.isFavorite == false, "Contact favorite status mismatch.")
        XCTAssert(contactDetailViewModel.telURL == URL(string: "tel://+910987654321"), "Contact phone number url mismatch.")
        XCTAssert(contactDetailViewModel.messageURL == URL(string: "sms://+910987654321"), "Contact message url mismatch.")
        XCTAssert(contactDetailViewModel.mailURL == URL(string: "mailto://nadeemakram2388@gmail.com"), "Contact email url mismatch.")
    }
}
