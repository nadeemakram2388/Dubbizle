//
//  ContactDetailErrorTests.swift
//  GoJekAssignmentTests
//
//  Created by Nadeem Akram on 24/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import XCTest

@testable import GoJekAssignment

class ContactDetailErrorTests: XCTestCase {

    var contact: Contact!
    var contactDetailViewModel: ContactDetailViewModel!

    override func setUp() {
        
        contact = MockContact.getPartial()
        
        let session = BadMockNetworkSession()
        let client = NetworkClient(session: session)
        contactDetailViewModel = ContactDetailViewModel(contact: contact, client: client)
    }

    override func tearDown() {
    }

    func testContactsAPIFailedResponse() {
        let expectation = self.expectation(description: "No error returns by contact API.")
        
        contactDetailViewModel.error.bind { (error) in
            if error != nil {
                expectation.fulfill()
            }
        }
        
        contactDetailViewModel.getContactDetails()
        self.waitForExpectations(timeout: 10.0, handler: nil)
    }
}
