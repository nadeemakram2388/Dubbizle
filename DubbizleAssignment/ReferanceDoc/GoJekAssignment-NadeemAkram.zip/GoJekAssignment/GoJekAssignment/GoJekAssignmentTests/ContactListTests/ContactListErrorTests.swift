//
//  ContactListErrorTests.swift
//  GoJekAssignmentTests
//
//  Created by Nadeem Akram on 24/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import XCTest

@testable import GoJekAssignment

class ContactListErrorTests: XCTestCase {

    var contactListViewModel: ContactListViewModel!

    override func setUp() {
        let session = BadMockNetworkSession()
        let client = NetworkClient(session: session)
        contactListViewModel = ContactListViewModel(client: client)
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testContactsAPIFailedResponse() {
        let expectation = self.expectation(description: "No error return by API.")
        
        contactListViewModel.error.bind { (error) in
            if error != nil {
                expectation.fulfill()
            }
        }
        
        contactListViewModel.getContacts()
        self.waitForExpectations(timeout: 10.0, handler: nil)
    }

}
