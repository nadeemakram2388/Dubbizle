//
//  README.md
//  GoJekAssignment
//
//  Created by Nadeem Akram on 24/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

 1. GO-JEK Assignment
GO-JEK Assignment by Nadeem Akram (nadeemakram2388@gmail.com)  from Sibani  (sibani.s.aux@go-jek.com).


 2. Requirements
- iOS 11.0+
- [Xcode 10.1](https://download.developer.apple.com/Developer_Tools/Xcode_10.1/Xcode_10.1.xip) 
- [CocoaPods](https://cocoapods.org/)
- [Fastlane](https://fastlane.tools)(Optional)

 3. Getting Start
- Open `GoJekAssignment.xcworkspace` in Xcode 10.1
- Build the project

 4. Problem Statements
[Problem Statements](ReferanceDoc/ProblemStatement.pdf)

 5. Swift
This project is build using Swift 4.2.

 6. 3rd Party
- [MBProgressHUD](https://github.com/jdg/MBProgressHUD)

​This project only using MBProgressHUD 3rd party dependency. Because less 3rd party means higher selection chances. I added this 3rd party just to demonstrate the use of the dependency manager (cocoapods).
​
​## 7. Unit and UI Test case
​- Total number of test cases - **`32`**
​- Unit test cases - **`18`**
​- UI test cases - **`14`**
​- Code coverage - **`72.7%`**
​
​I'm not using any 3rd parting to mocking and stubs the objects. I build my own protocol based solution by creating fake `URLSession`.
​![](ReferanceDoc/XcodeTestCoverage.png)
​![](ReferanceDoc/FastLaneResult.png)
​
​## 8. Architecture
​In this project, I'm using MVVM architecture without any Reactive 3rd party lib(like RxSwift etc.). For binding purposes, I'm using the custom binding class to bind properties and UI elements with ViewModels. These custom classes are available [here](GoJekAssignment/Utilities/Binding).
​
​## 9. Memory Management
​![](ReferanceDoc/MemoryLeaks.png)
​
​## 10. Extra Feature
​I'm using CoreData to store contacts locally. Which means you can view contacts offline but with limited functionality. Like you can't add new contact or update existing.
​
​## 11. Fastlane 
​- `fastlane ios tests` - Runs all the tests
​- `fastlane build` - Run all the tests and build
