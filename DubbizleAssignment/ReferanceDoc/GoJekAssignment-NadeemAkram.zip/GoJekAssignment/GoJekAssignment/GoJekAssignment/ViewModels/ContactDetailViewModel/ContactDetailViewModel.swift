//
//  ContactDetailViewModel.swift
//  GoJekAssignment
//
//  Created by Nadeem Akram on 23/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import Foundation

class ContactDetailViewModel {
    
    private var httpClient: NetworkClient!
    
    let editBarButtonTitle = AppText.Edit.localized
    
    var contact: Binding<Contact>!
    var isBusy: Binding<Bool> = Binding(false)
    var error: Binding<NetworkError?> = Binding(nil)
    
    // MARK: - Computed Properties
    var contactMetadata: [ContactMetadata] {
        return contact.value.getDetailsMetadata()
    }
    
    var name: String {
        return contact.value.fullName
    }
    
    var imageURL: URL? {
        return URL(string: contact.value.profilePic ?? "")
    }
    
    var isFavorite: Bool {
        return contact.value.favorite
    }
    
    var telURL: URL? {
        if let phone = contact.value.phoneNumber {
            return URL(string: String(format: "tel://%@", phone))
        }
        return nil
    }
    
    var messageURL: URL? {
        if let phone = contact.value.phoneNumber {
            return URL(string: String(format: "sms://%@", phone))
        }
        return nil
    }
    
    var mailURL: URL? {
        if let email = contact.value.email {
            return URL(string: String(format: "mailto://%@", email))
        }
        return nil
    }
    
    init(contact: Contact, client: NetworkClient? = nil) {
        self.contact = Binding(contact)
        self.httpClient = client ?? NetworkClient.shared
    }
    
    func getContactDetails() {
        isBusy.value = true
        httpClient.dataTask(NetworkAPI.getContact(id: Int(contact.value.id))) { [weak self] (result) in
            guard let self = self else {
                return
            }
            
            self.isBusy.value = false
            switch result {
            case .success(let data):
                guard let data = data else {
                    return
                }
                
                do {
                    let contact = try JSONDecoder().decode(Contact.self, from: data)
                    CoreDataHelper.shared.saveContext()
                    self.contact.value = contact
                } catch {
                    Log.error("Unable to decode Contact.", error: error)
                }
            case .failure(let error):
                self.error.value = NetworkError(error.localizedDescription)
                Log.error("Error in fetching Contact.", error: error)
            }
        }
    }
    
    func updateFavourite() {
        contact.value.favorite = !contact.value.favorite
        let contactRequest = NetworkAPI.updateContact(id: Int(contact.value.id), contact: contact.value)
        isBusy.value = true
        httpClient.dataTask(contactRequest) { [weak self] (result) in
            guard let self = self else {
                return
            }
            
            self.isBusy.value = false
            switch result {
            case .success(let data):
                guard let data = data else {
                    return
                }
                
                do {
                    let contact = try JSONDecoder().decode(Contact.self, from: data)
                    CoreDataHelper.shared.saveContext()
                    self.contact.value = contact
                } catch {
                    Log.error("Unable to decode Contact.", error: error)
                }
            case .failure(let error):
                self.error.value = NetworkError(error.localizedDescription)
                self.contact.value.favorite = !self.contact.value.favorite
                Log.error("Error in updating Contact.", error: error)
            }
        }
    }
}
