//
//  AddContactViewModel.swift
//  GoJekAssignment
//
//  Created by Nadeem Akram on 23/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import Foundation
import CoreData

class AddContactViewModel {
    private var editMode: Bool
    
    let doneBarButtonTitle = AppText.Done.localized
    let cancelBarButtonTitle = AppText.Cancel.localized
    let managedObjectContext = CoreDataHelper.shared.managedObjectContext
    
    var contact: Binding<Contact>!
    var contactMetadata: [ContactMetadata]!
    var isBusy: Binding<Bool> = Binding(false)
    var isContactSync: Binding<Bool> = Binding(false)
    var error: Binding<NetworkError?> = Binding(nil)
    
    init(contact: Contact?) {
        
        if let contact = contact {
            editMode = true
            self.contact = Binding(contact)
            self.contactMetadata = self.contact.value.getEditMetaData()
        } else {
            editMode = false
            guard let entity = NSEntityDescription.entity(forEntityName: Contact.name, in: managedObjectContext) else {
                fatalError("Failed to decode Contact")
            }
            
            self.contact = Binding(Contact(entity: entity, insertInto: nil))
            self.contactMetadata = self.contact.value.getEditMetaData()
        }
    }
    
    func syncContact() {
        //Validate Contact
        if !validateContact() { return }
        
        var request: NetworkRequestProtocol = NetworkAPI.addContact(contact: contact.value)
        if editMode {
            request = NetworkAPI.updateContact(id: Int(contact.value.id), contact: contact.value)
        }
        
        isBusy.value = true
        NetworkClient.shared.dataTask(request) { [weak self] (result) in
            guard let self = self else {
                return
            }
            
            self.isBusy.value = false
            switch result {
            case .success(let data):
                guard let data = data else {
                    return
                }
                
                do {
                    let contact = try JSONDecoder().decode(Contact.self, from: data)
                    CoreDataHelper.shared.saveContext()
                    self.isContactSync.value = true
                    self.contact.value = contact
                } catch {
                    self.error.value = NetworkError(error.localizedDescription)
                    Log.error("Unable to decode contact.", error: error)
                }
            case .failure(let error):
                self.error.value = NetworkError(error.localizedDescription)
                Log.error("Error in contact sync.", error: error)
            }
        }
    }
    
    private func validateContact() -> Bool {
        guard let firstName = contact.value.firstName else {
            error.value = NetworkError(AppText.PleaseEnterFirstName.localized)
            return false
        }
        
        if firstName.count < 2 {
            let message = AppText.FirstNameMinLength.localized
            error.value = NetworkError(message)
            return false
        }
        
        guard let lastName = contact.value.lastName else {
            error.value = NetworkError(AppText.PleaseEnterLastName.localized)
            return false
        }
        
        if lastName.count < 2 {
            let message = AppText.LastNameMinLength.localized
            error.value = NetworkError(message)
            return false
        }
        
        if let mobile = contact.value.phoneNumber, mobile.count < 10 {
            let message = AppText.PleaseEnterValidMobile.localized
            error.value = NetworkError(message)
            return false
        }
        
        if let email = contact.value.email {
            let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
            let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegEx)
            if !emailPredicate.evaluate(with: email) {
                error.value = NetworkError(AppText.PleaseEnterValidEmail.localized)
                return false
            }
        }
        return true
    }
}
