//
//  ContactViewModel.swift
//  GoJekAssignment
//
//  Created by Nadeem Akram on 22/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import Foundation
class ContactViewModel {
    private let contact: Contact!
    
    let name: String
    let imageURL: URL?
    let isFavorite: Bool
    
    init(contact: Contact) {
        self.contact = contact
        
        name = contact.fullName
        imageURL = URL(string: contact.profilePic ?? "")
        isFavorite = contact.favorite
    }
}
