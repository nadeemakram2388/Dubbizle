//
//  ContactListViewModel.swift
//  GoJekAssignment
//
//  Created by Nadeem Akram on 22/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import Foundation

class ContactListViewModel {
    
    private var httpClient: NetworkClient!
    
    let title = AppText.Contact.localized
    let groupBarButtonTitle = AppText.Groups.localized
    
    var isBusy: Binding<Bool> = Binding(false)
    var contacts: Binding<[Contact]?> = Binding(nil)
    var error: Binding<NetworkError?> = Binding(nil)
    
    init(client: NetworkClient? = nil) {
        self.httpClient = client ?? NetworkClient.shared
    }
    
    func getContacts() {
        isBusy.value = true
        httpClient.dataTask(NetworkAPI.getContacts) { [weak self] (result) in
            guard let self = self else {
                return
            }
            
            self.isBusy.value = false
            switch result {
            case .success(let data):
                guard let data = data else {
                    return
                }
                
                do {
                    Contact.deleteAllContacts()
                    let contacts = try JSONDecoder().decode([Contact].self, from: data)
                    CoreDataHelper.shared.saveContext()
                    self.contacts.value = contacts
                    Log.info("Contact sync successfully.")
                } catch {
                    Log.error("Unable to decode Contact List", error: error)
                }
            case .failure(let error):
                self.error.value = NetworkError(error.localizedDescription)
                Log.error("Error in fetching Contacts", error: error)
            }
        }
    }
}
