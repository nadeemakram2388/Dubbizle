//
//  ContactTableViewCell.swift
//  GoJekAssignment
//
//  Created by Nadeem Akram on 22/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import UIKit

class ContactTableViewCell: UITableViewCell {

    @IBOutlet weak var contactImageView: UIImageView!
    @IBOutlet weak var contactName: UILabel!
    @IBOutlet weak var favoriteImageView: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        contactImageView.makeCircle()
    }
    
    func config(contact: Contact) {
        let viewModel = ContactViewModel(contact: contact)
        contactName.text = viewModel.name
        contactImageView.image = UIImage.Contact.placeHolder
        favoriteImageView.isHidden = !viewModel.isFavorite
        favoriteImageView.image = viewModel.isFavorite ? UIImage.Contact.showFavorite : nil
    }

    
}
