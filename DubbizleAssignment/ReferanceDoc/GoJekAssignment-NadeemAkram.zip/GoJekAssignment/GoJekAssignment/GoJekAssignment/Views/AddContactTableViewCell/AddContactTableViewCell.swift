//
//  AddContactTableViewCell.swift
//  GoJekAssignment
//
//  Created by Nadeem Akram on 23/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import UIKit

protocol AddContactTableViewCellDelegate: class {
    func textChanged(contactMetaData: ContactMetadata, text: String)
}

class AddContactTableViewCell: UITableViewCell {

    @IBOutlet weak var descLabel: UILabel!
    @IBOutlet weak var infoTextField: BindedTextField! {
        didSet {
            infoTextField.bind {[weak self] in
                guard let self = self else {
                    return
                }
                self.delegate?.textChanged(contactMetaData: self.contactMetadata, text: $0)
            }
        }
    }
    
    var contactMetadata: ContactMetadata!
    weak var delegate: AddContactTableViewCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    func config(metaData: ContactMetadata) {
        contactMetadata = metaData
        descLabel.text = metaData.desc
        infoTextField.text = metaData.info
        infoTextField.keyboardType = metaData.keyboardType
    }

}
