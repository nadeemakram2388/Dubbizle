//
//  AddContactTableHeaderView.swift
//  GoJekAssignment
//
//  Created by Nadeem Akram on 23/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import UIKit

protocol AddContactTableHeaderViewDelegate: class {
    func getImageAction(_ sender: UIButton)
}

class AddContactTableHeaderView: UIView {

    @IBOutlet weak var imageView: CircularImageView!
    @IBOutlet weak var takeImageButton: UIButton!
    
    weak var delegate: AddContactTableHeaderViewDelegate?
    
    @IBAction func takeImageButtonAction(_ sender: UIButton) {
        delegate?.getImageAction(sender)
    }
}
