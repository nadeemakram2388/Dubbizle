//
//  ContactDetailTableViewCell.swift
//  GoJekAssignment
//
//  Created by Nadeem Akram on 23/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import UIKit

class ContactDetailTableViewCell: UITableViewCell {

    @IBOutlet weak var descLabel: UILabel!
    @IBOutlet weak var infoLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func config(metaData: ContactMetadata) {
        descLabel.text = metaData.desc
        infoLabel.text = metaData.info
    }
}
