//
//  AddContactViewController.swift
//  GoJekAssignment
//
//  Created by Nadeem Akram on 23/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import UIKit

protocol AddContactViewControllerDelegate: class {
    func syncContact(_ contact: Contact)
}

class AddContactViewController: UIViewController {

    // MARK: - Outlet
    @IBOutlet weak var tableView: UITableView!
    
    // MARK: - Weak Properties and Delgate
    weak var tableViewHeader: AddContactTableHeaderView?
    weak var delegate: AddContactViewControllerDelegate?
    
    // MARK: - Internal Properties
    var imagePicker: ImagePicker!
    
    // MARK: - Properties
    var viewModel: AddContactViewModel?

    // MARK: - View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()

        setupTableView()
        setupImagePicker()
        setupBindingAndGetContact()
        setupNavigationBarButtonItems()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let frame = CGRect(x: 0, y: 0, width: view.frame.width, height: UIScreen.main.bounds.size.height * (150 / 667))
        tableView.tableHeaderView?.frame = frame
    }
    
    // MARK: - Helper Functions
    private func setupNavigationBarButtonItems() {
        navigationController?.navigationBar.shadowImage = UIImage()
        
        //set cancel and done bar button item
        let cancelBarButtonItem = UIBarButtonItem(title: viewModel?.cancelBarButtonTitle,
                                                  style: .plain,
                                                  target: self,
                                                  action: #selector(cancelBarButtonItemAction))
        navigationItem.leftBarButtonItem = cancelBarButtonItem
        
        let doneBarButtonItem = UIBarButtonItem(title: viewModel?.doneBarButtonTitle,
                                                style: .done,
                                                target: self,
                                                action: #selector(doneBarButtonItemAction))
        navigationItem.rightBarButtonItem = doneBarButtonItem
    }
    
    private func setupTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.tableFooterView = UIView(frame: CGRect.zero)
        tableView.register(nib: AddContactTableViewCell.name)
        tableView.accessibilityIdentifier = "addContactTableView"

        tableViewHeader = AppCoordinator.getAddContactTableHeaderView()
        tableViewHeader?.delegate = self
        tableView.tableHeaderView = tableViewHeader
    }
    
    private func setupImagePicker() {
        imagePicker = ImagePicker(from: self)
        imagePicker.delegate = self
    }
    
    private func setupBindingAndGetContact() {
        //Binding
        viewModel?.isBusy.bind { [unowned self] isBusy in
            self.navigationController?.view.showLoader(show: isBusy)
        }
        
        viewModel?.isContactSync.bind { [unowned self] (isSync) in
            if isSync {
                if let contact = self.viewModel?.contact.value {
                    self.delegate?.syncContact(contact)
                }
                self.dismiss(animated: true, completion: nil)
            }
        }
        
        viewModel?.contact.bind(listener: {[unowned self] (_) in
            self.tableView.reloadData()
        })
        
        viewModel?.error.bind { [unowned self] (error) in
            if let error = error {
                UIAlertController.show(error.localizedDescription, from: self)
            }
        }
    }
    
    @objc private func cancelBarButtonItemAction() {
        view.endEditing(true)
        dismiss(animated: true, completion: nil)
    }
    
    @objc private func doneBarButtonItemAction() {
        view.endEditing(true)
        viewModel?.syncContact()
    }

}
