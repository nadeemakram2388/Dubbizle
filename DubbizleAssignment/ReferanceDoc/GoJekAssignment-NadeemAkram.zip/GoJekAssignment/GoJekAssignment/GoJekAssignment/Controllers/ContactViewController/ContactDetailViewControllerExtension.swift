//
//  ContactDetailViewControllerExtension.swift
//  GoJekAssignment
//
//  Created by Nadeem Akram on 23/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import Foundation
import UIKit

extension ContactDetailViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel?.contactMetadata.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: ContactDetailTableViewCell.name,
                                                       for: indexPath) as? ContactDetailTableViewCell else {
                                                        fatalError("Unable to dequeue ContactDetailTableViewCell cell.")
        }
        if let contactMetaDataArr = viewModel?.contactMetadata, contactMetaDataArr.count > indexPath.row {
            let contactMetaData = contactMetaDataArr[indexPath.row]
            cell.config(metaData: contactMetaData)
        }
        cell.accessibilityIdentifier = String(format: "detailsTableViewCell_%ld", indexPath.row)
        return cell
    }
}

extension ContactDetailViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 56
    }
}

extension ContactDetailViewController: AddContactViewControllerDelegate {
    func syncContact(_ contact: Contact) {
        viewModel?.contact.value = contact
    }
}
