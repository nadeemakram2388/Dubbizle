//
//  ContactListViewController.swift
//  GoJekAssignment
//
//  Created by Nadeem Akram on 21/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import UIKit
import CoreData

class ContactListViewController: UIViewController {

    // MARK: - Outlet
    @IBOutlet weak var contactTableView: UITableView!
    var viewModel: ContactListViewModel?
    var fetchedResultController: NSFetchedResultsController<Contact>?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = viewModel?.title

        // Do any additional setup after loading the view.
        setUpTableView()
        setupNavigationBarButtonItems()
        setupFetchedResultController()
        setupBindingAndGetContacts()
    }

    // MARK: - Helper Functions
    private func setUpTableView() {
        contactTableView.delegate = self
        contactTableView.dataSource = self
        contactTableView.tableFooterView = UIView(frame: CGRect.zero)
        contactTableView.register(nib: ContactTableViewCell.name)
        // accessibilityIdentifier
        contactTableView.accessibilityIdentifier = "contactListTableView"
    }
    
    private func setupNavigationBarButtonItems() {
        let groupsBarButtonItem = UIBarButtonItem(title: viewModel?.groupBarButtonTitle,
                                                  style: .plain,
                                                  target: self,
                                                  action: nil)
        navigationItem.leftBarButtonItem = groupsBarButtonItem
        
        let addContactBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add,
                                                      target: self,
                                                      action: #selector(addContactBarButtonItemAction))
        navigationItem.rightBarButtonItem = addContactBarButtonItem
    }
    
    private func setupFetchedResultController() {
        let contactsFetchRequest: NSFetchRequest<Contact> = Contact.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: #keyPath(Contact.firstName),
                                              ascending: true,
                                              selector: #selector(NSString.caseInsensitiveCompare(_:)))
        contactsFetchRequest.sortDescriptors = [sortDescriptor]
        let managedObjectContext = CoreDataHelper.shared.managedObjectContext
        fetchedResultController = .init(fetchRequest: contactsFetchRequest,
                                        managedObjectContext: managedObjectContext,
                                        sectionNameKeyPath: #keyPath(Contact.sectionTitle),
                                        cacheName: nil)
        fetchedResultController?.delegate = self
    }
    
    private func performFetchRequest() {
        do {
            try fetchedResultController?.performFetch()
            contactTableView.reloadData()
        } catch {
            Log.error("Unable to perform fetch operation from DB.", error: error)
        }
    }
    
    private func setupBindingAndGetContacts() {
        //Binding
        viewModel?.isBusy.bind { [unowned self] isBusy in
            self.view.showLoader(show: isBusy)
        }
        
        viewModel?.contacts.bind { [unowned self] (contacts) in
            if contacts != nil {
                self.performFetchRequest()
            }
        }
        
        viewModel?.error.bind { [unowned self] (error) in
            if let error = error {
                self.performFetchRequest()
                UIAlertController.show(error.localizedDescription, from: self)
            }
        }
        //Get Contacts
        viewModel?.getContacts()
    }
    
    @objc private func addContactBarButtonItemAction() {
        AppCoordinator.toAddContact()
    }

}
