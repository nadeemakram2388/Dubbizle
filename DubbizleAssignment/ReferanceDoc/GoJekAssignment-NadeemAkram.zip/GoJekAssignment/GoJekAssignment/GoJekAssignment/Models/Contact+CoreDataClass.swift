//
//  Contact+CoreDataClass.swift
//  GoJekAssignment
//
//  Created by Nadeem Akram on 22/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import Foundation
import CoreData

extension Contact {
    public var fullName: String {
        let seprator = (firstName != nil) ? " " : ""
        return (firstName ?? "") + seprator + (lastName ?? "")
    }
    
    @objc public var sectionTitle: String {
        if let firstChar = firstName?.uppercased().first {
            let firstCharString = "\(firstChar)"
            if firstCharString >= "A" && firstCharString <= "Z" {
                return firstCharString
            }
        }
        return "#"
    }
    
    @nonobjc public class func fetchRequest() -> NSFetchRequest<Contact> {
        return NSFetchRequest<Contact>(entityName: Contact.name)
    }
    
    public class func getContact(id: Int) -> Contact? {
        let fetchRequest: NSFetchRequest<Contact> = Contact.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "id=%ld", id)
        fetchRequest.fetchLimit = 1
        do {
            let contacts: [Contact] = try CoreDataHelper.shared.managedObjectContext.fetch(fetchRequest)
            return contacts.first
        } catch {
            Log.error("Unable to fetch contact with id \(id).", error: error)
        }
        return nil
    }
    
    public class func deleteAllContacts() {
        let fetchRequest: NSFetchRequest<NSFetchRequestResult> = Contact.fetchRequest()
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        deleteRequest.resultType = .resultTypeObjectIDs
        
        // perform the delete
        do {
            let managedObjectContext = CoreDataHelper.shared.managedObjectContext
            let result = try managedObjectContext.execute(deleteRequest) as? NSBatchDeleteResult
            let managedObjectIds = result?.result as? [NSManagedObjectID] ?? []
            let changes: [AnyHashable: Any] = [NSDeletedObjectsKey: managedObjectIds]
            NSManagedObjectContext.mergeChanges(fromRemoteContextSave: changes, into: [managedObjectContext])
        } catch let error as NSError {
            Log.error("Unable to delete existing contacts.", error: error)
        }
    }
    
    func getDetailsMetadata() -> [ContactMetadata] {
        let phoneMetadata = ContactMetadata(desc: AppText.mobile.localized,
                                            info: phoneNumber, type: .mobile, keyboardType: .phonePad)
        let emailMetadata = ContactMetadata(desc: AppText.email.localized,
                                            info: email, type: .email, keyboardType: .emailAddress)
        return [phoneMetadata, emailMetadata]
    }
    
    func getEditMetaData() -> [ContactMetadata] {
        let firstNameMetaData = ContactMetadata(desc: AppText.FirstName.localized,
                                                info: firstName, type: .firstName)
        
        let lastNameMetaData = ContactMetadata(desc: AppText.LastName.localized,
                                               info: lastName, type: .lastName)
        
        return [firstNameMetaData, lastNameMetaData] + getDetailsMetadata()
    }

}
