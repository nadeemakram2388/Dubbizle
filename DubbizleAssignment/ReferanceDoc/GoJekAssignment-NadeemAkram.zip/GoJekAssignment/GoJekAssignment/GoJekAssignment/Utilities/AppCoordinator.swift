//
//  AppCoordinator.swift
//  GoJekAssignment
//
//  Created by Nadeem Akram on 24/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import Foundation
import UIKit

class AppCoordinator {
    
    class func getRootController() -> UINavigationController {
        let contactViewController = ContactListViewController(nibName: ContactListViewController.name, bundle: nil)
        contactViewController.viewModel = ContactListViewModel()
        return UINavigationController(rootViewController: contactViewController)
    }
    
    class func toAddContact() {
        let addContactViewController = AddContactViewController(nibName: AddContactViewController.name, bundle: nil)
        addContactViewController.viewModel = AddContactViewModel(contact: nil)
        let navigationController = UINavigationController(rootViewController: addContactViewController)
        UIApplication.shared.keyWindow?.rootViewController?.present(
            navigationController, animated: true, completion: nil)
    }
    
    class func toEditContact(contact: Contact, delegate: AddContactViewControllerDelegate? = nil) {
        let addContactViewController = AddContactViewController(nibName: AddContactViewController.name, bundle: nil)
        addContactViewController.delegate = delegate
        addContactViewController.viewModel = AddContactViewModel(contact: contact)
        let navigationController = UINavigationController(rootViewController: addContactViewController)
        UIApplication.shared.keyWindow?.rootViewController?.present(
            navigationController, animated: true, completion: nil)
    }

    class func toContactDetail(contact: Contact, navigationController: UINavigationController?) {
        let contactDetailViewController = ContactDetailViewController(nibName: ContactDetailViewController.name, bundle: nil)
        contactDetailViewController.viewModel = ContactDetailViewModel(contact: contact)
        navigationController?.pushViewController(contactDetailViewController, animated: true)
    }
    
    class func getAddContactTableHeaderView(image: UIImage = UIImage.Contact.placeHolder) -> AddContactTableHeaderView? {
        guard let view = Bundle.main.loadNibNamed(AddContactTableHeaderView.name,
                                                  owner: nil, options: nil)?
            .first as? AddContactTableHeaderView else {
                return nil
        }
        view.imageView.image = image
        return view
    }




}
