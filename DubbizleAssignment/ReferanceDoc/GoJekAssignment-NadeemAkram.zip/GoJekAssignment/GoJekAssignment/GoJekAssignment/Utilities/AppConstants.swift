//
//  Constants.swift
//  GoJekAssignment
//
//  Created by Nadeem Akram on 22/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import Foundation

struct AppConstants {
    
}

enum AppText: String {
    
    case Done = "Done"
    case Cancel = "Cancel"
    case mobile = "mobile"
    case email = "email"
    case FirstName = "First Name"
    case LastName = "Last Name"
    case SomthingWentWrong = "Somthing went wrong!"
    case PleaseEnterFirstName = "Please enter first name."
    case FirstNameMinLength = "First name is too short (minimum is 2 characters)"
    case PleaseEnterLastName = "Please enter last name."
    case LastNameMinLength = "Last name is too short (minimum is 2 characters)"
    case PleaseEnterValidMobile = "Please enter a vailid mobile number. Mobile number should be of 10 digits or more."
    case PleaseEnterValidEmail = "Please enter a valid email."
    case Contact = "Contact"
    case Groups = "Groups"
    case Edit = "Edit"
    case Add = "Add"


    // Mark- Localized Value
    var localized: String {
        return NSLocalizedString(self.rawValue, comment: "")
    }
}
