//
//  CircularImageView.swift
//  GoJekAssignment
//
//  Created by Nadeem Akram on 23/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import UIKit

@IBDesignable class CircularImageView: UIImageView {
    override func layoutSubviews() {
        super.layoutSubviews()
        layer.cornerRadius = frame.height / 2
        layer.masksToBounds = true
        clipsToBounds = true
    }
}

