//
//  BindedTextField.swift
//  GoJekAssignment
//
//  Created by Nadeem Akram on 22/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import Foundation
import UIKit

class BindedTextField: UITextField {
    
    typealias EventListener = (String) -> Void
    var textChanged: EventListener = { _ in }
    
    func bind(listener: @escaping EventListener) {
        self.textChanged = listener
        self.addTarget(self, action: #selector(textFieldDidChanged(_:)), for: .editingChanged)
    }
    
    @objc func textFieldDidChanged(_ textField: UITextField) {
        self.textChanged(textField.text!)
    }
}
