//
//  NSObjectExtension.swift
//  GoJekAssignment
//
//  Created by Nadeem Akram on 21/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import Foundation

extension NSObject {
    class var name: String {
        return String(describing: self)
    }
}
