//
//  UIImageViewExtension.swift
//  GoJekAssignment
//
//  Created by Nadeem Akram on 22/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import Foundation
import UIKit

extension UIImageView {
    func makeCircle() {
        layer.cornerRadius = bounds.height / 2
        layer.masksToBounds = true
    }
}
