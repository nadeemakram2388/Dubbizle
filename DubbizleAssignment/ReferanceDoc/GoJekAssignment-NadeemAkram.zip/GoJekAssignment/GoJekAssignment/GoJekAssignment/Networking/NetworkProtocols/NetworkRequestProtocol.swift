//
//  NetworkRequestProtocol.swift
//  GoJekAssignment
//
//  Created by Nadeem Akram on 22/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import Foundation
public typealias HTTPHeaders = [String: String]

protocol NetworkRequestProtocol {
    var baseURL: URL { get }
    var path: String { get }
    var httpMethod: HTTPMethod { get }
    var httpBody: Data? { get }
    var headers: HTTPHeaders? { get }
}
