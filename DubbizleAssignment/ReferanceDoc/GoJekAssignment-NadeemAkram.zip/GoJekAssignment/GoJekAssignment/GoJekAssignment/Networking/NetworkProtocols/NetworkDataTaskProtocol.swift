//
//  NetworkDataTaskProtocal.swift
//  GoJekAssignment
//
//  Created by Nadeem Akram on 22/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import Foundation

protocol NetworkDataTaskProtocol {
    func resume()
    func cancel()
}
