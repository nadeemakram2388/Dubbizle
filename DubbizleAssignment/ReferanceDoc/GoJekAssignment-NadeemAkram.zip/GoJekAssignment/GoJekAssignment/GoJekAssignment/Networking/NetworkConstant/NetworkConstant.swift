//
//  NetworkConstant.swift
//  GoJekAssignment
//
//  Created by Nadeem Akram on 22/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import Foundation

extension AppConstants {
    struct Service {
        static let baseURL = "https://gojek-contacts-app.herokuapp.com/"
        static let timeout: TimeInterval = 60.0
    }
}
