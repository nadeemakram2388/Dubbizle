//
//  NetworkDataTaskExtension.swift
//  GoJekAssignment
//
//  Created by Nadeem Akram on 22/12/19.
//  Copyright © 2019 Nadeem Akram. All rights reserved.
//

import Foundation
extension URLSessionDataTask: NetworkDataTaskProtocol {
    
}
